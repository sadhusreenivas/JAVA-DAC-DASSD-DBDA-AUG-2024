package com.example.notify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotifyApiServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
