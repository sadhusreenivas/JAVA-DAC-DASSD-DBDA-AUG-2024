package com.example.posts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostApiServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
