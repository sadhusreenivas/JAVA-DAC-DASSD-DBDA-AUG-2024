/**
 * 
 */
/**
 * 
 */
module StreamAPIapp {
	requires java.base;
	
}